"""Step 3 of the batch run: runs all four experiments (Q1-Q4) on built.pkl and saves tables, results.json and figures.
Usage: python run_experiments.py <pickle_dir> <out_dir>
"""
import sys, os, json, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from scipy.stats import spearmanr
from exp_load import load
from pipeline import PARAMS, clean_ride, smooth, ride_features, to_xy
import clustering as cl, hotspots as hs

P_DIR, OUT = sys.argv[1], sys.argv[2]
FIG = os.path.join(OUT, 'figures'); os.makedirs(FIG, exist_ok=True)
INK, INK2, GRID = '#0b0b0b', '#52514e', '#e4e3df'
BLUE, ORANGE, AQUA, YELLOW, GRAY = '#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#a3a29d'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10, 'axes.edgecolor': INK2, 'axes.labelcolor': INK,
                     'xtick.color': INK2, 'ytick.color': INK2, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.titlesize': 11, 'axes.titleweight': 'bold', 'legend.frameon': False})
R = {}
F, pts, inc, d = load(P_DIR)
W = F[F.config == 'raw']

# ---------- data description ----------
log = d['log']
R['data'] = dict(files=int(log.files.sum()), gps_fixes=int(log.gps_fixes.sum()), dropped_acc=int(log.dropped_acc.sum()),
                 dropped_spike=int(log.dropped_spike.sum()), rides=int(W.ride.nunique()),
                 rides_by_month=W.groupby('month').size().to_dict(), km=float(W.dist_km.sum()),
                 incidents=int(len(inc)), incidents_by_month=inc.groupby('month').size().to_dict(),
                 scary=int(inc.scary.sum()), points_smoothed=int(len(pts)),
                 ploc=W.ploc.value_counts().to_dict())

# ---------- Q1 smoothing ----------
rows = []
for c, X in F.groupby('config', sort=False):
    rows.append(dict(config=c, pos_window=int(X.pos_window.iloc[0]), speed_window=int(X.speed_window.iloc[0]),
                     rho_acc=spearmanr(X.acc_std, X.gps_acc_med).statistic,
                     rho_turn=spearmanr(X.turns_per_km, X.gps_acc_med).statistic,
                     turns_med=X.turns_per_km.median(), moving_med=X.moving_kmh.median(), stops_med=X.stops_per_km.median()))
Q1 = pd.DataFrame(rows); Q1.to_csv(os.path.join(OUT, 'q1_smoothing.csv'), index=False); R['q1'] = Q1.round(3).to_dict('records')
jun = F[F.month == '2023_06']
R['q1_june'] = {c: round(spearmanr(X.acc_std, X.gps_acc_med).statistic, 3) for c, X in jun.groupby('config')}

# Fig 1: correlation with GPS error by configuration
sel = ['raw', 'pos5', 'speed5', 'both5']
lab = {'raw': 'No smoothing\n(midterm)', 'pos5': 'Position\nsmoothing', 'speed5': 'Speed\nsmoothing', 'both5': 'Both\n(proposed)'}
q = Q1.set_index('config').loc[sel]
fig, ax = plt.subplots(figsize=(6.5, 3.2), dpi=200)
x = np.arange(len(sel)); wbar = 0.36
b1 = ax.bar(x - wbar / 2 - 0.01, q.rho_acc, wbar, color=BLUE, label='Acceleration variability')
b2 = ax.bar(x + wbar / 2 + 0.01, q.rho_turn, wbar, color=ORANGE, label='Turns per km')
for bars in (b1, b2):
    for b in bars: ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.012, f'{b.get_height():.2f}', ha='center', fontsize=8.5, color=INK)
ax.set_xticks(x); ax.set_xticklabels([lab[s] for s in sel])
ax.set_ylabel('Spearman correlation with\nGPS error radius'); ax.set_ylim(0, 0.75)
ax.yaxis.grid(True, color=GRID); ax.set_axisbelow(True); ax.legend(loc='upper right', ncol=2, fontsize=8.5)
fig.tight_layout(); fig.savefig(os.path.join(FIG, 'fig1_smoothing.png')); plt.close()

# Fig 2: one noisy ride, raw vs smoothed trace
g_all = pd.read_pickle(f'{P_DIR}/m_2023_06.pkl')['gps']
for c in ['lat', 'lon', 'timeStamp', 'acc']: g_all[c] = pd.to_numeric(g_all[c], errors='coerce')
cand = F[(F.config == 'raw') & (F.month == '2023_06') & F.dist_km.between(1.5, 6)].sort_values('gps_acc_med', ascending=False).ride.head(60)
best = None
for r_ in cand:
    gc_, _ = clean_ride(g_all[g_all.ride == r_])
    if gc_ is None or len(gc_) < 60: continue
    gs_ = smooth(gc_, 5); a0, b0 = to_xy(gc_.lat.values, gc_.lon.values); a1, b1 = to_xy(gs_.lat.values, gs_.lon.values)
    dv = pd.Series(np.hypot(a0 - a1, b0 - b1)).rolling(40, center=True, min_periods=1).mean()
    if best is None or dv.max() > best[0]: best = (dv.max(), r_, int(dv.idxmax()))
_, rid, k = best
gc, _ = clean_ride(g_all[g_all.ride == rid]); gs = smooth(gc, 5)
x0, y0 = to_xy(gc.lat.values, gc.lon.values); x1, y1 = to_xy(gs.lat.values, gs.lon.values)
lo_, hi_ = max(0, k - 20), min(len(x0), k + 20)
x0, y0, x1, y1 = x0[lo_:hi_], y0[lo_:hi_], x1[lo_:hi_], y1[lo_:hi_]
ox, oy = min(x0.min(), x1.min()), min(y0.min(), y1.min())
fr = F[(F.ride == rid)].set_index('config')
fig, ax = plt.subplots(figsize=(6.5, 3.6), dpi=200)
ax.plot(x0 - ox, y0 - oy, color=GRAY, lw=1.2, marker='o', ms=2.2, label=f"Raw GPS fixes (whole ride: {fr.loc['raw','turns_per_km']:.1f} turns/km)")
ax.plot(x1 - ox, y1 - oy, color=BLUE, lw=2, label=f"Smoothed, window 5 (whole ride: {fr.loc['both5','turns_per_km']:.1f} turns/km)")
ax.set_aspect('equal'); ax.set_xlabel('East (m)'); ax.set_ylabel('North (m)')
ax.grid(True, color=GRID); ax.set_axisbelow(True); ax.legend(loc='best', fontsize=8.5)
fig.tight_layout(); fig.savefig(os.path.join(FIG, 'fig2_trace.png')); plt.close()
R['fig2'] = dict(ride=rid, gps_err=float(fr.loc['raw', 'gps_acc_med']), turns_raw=float(fr.loc['raw', 'turns_per_km']), turns_smooth=float(fr.loc['both5', 'turns_per_km']), km=float(fr.loc['raw','dist_km']))

# ---------- Q2 clustering ----------
variants = [('Baseline (midterm)', 'raw', False), ('Smoothing only', 'both5', False),
            ('Phone control only', 'raw', True), ('Proposed', 'both5', True)]
rows, labels = [], {}
for scope, months in [('All 3 months', ['2023_05', '2023_06', '2023_07']), ('June only', ['2023_06'])]:
    for name, cfg, pc in variants:
        X = F[(F.config == cfg) & F.month.isin(months)].dropna(subset=cl.FEATS).reset_index(drop=True)
        lab_, m = cl.evaluate(X, pc, 3); m.update(method=name, scope=scope, n=len(X)); rows.append(m)
        labels[(scope, name)] = (X, lab_)
Q2 = pd.DataFrame(rows); Q2.to_csv(os.path.join(OUT, 'q2_clustering.csv'), index=False); R['q2'] = Q2.round(3).to_dict('records')
sil = {}
for name, cfg, pc in [('Baseline (midterm)', 'raw', False), ('Proposed', 'both5', True)]:
    X = F[F.config == cfg].dropna(subset=cl.FEATS).reset_index(drop=True); Z = cl.design(X, pc).values
    sil[name] = [float(cl.silhouette_score(Z, cl.KMeans(k, n_init=10, random_state=0).fit_predict(Z))) for k in range(2, 7)]
R['q2_sil_by_k'] = sil

# cluster profiles (proposed, all months) + June baseline phone shares
ic = inc.groupby('ride').size(); sc = inc.groupby('ride').scary.sum()
X, lab_ = labels[('All 3 months', 'Proposed')]; X = X.copy(); X['cl'] = lab_
X['inc'] = X.ride.map(ic).fillna(0); X['scary'] = X.ride.map(sc).fillna(0)
g = X.groupby('cl')
prof = g[['moving_kmh', 'p95_kmh', 'stops_per_km', 'stop_share', 'turns_per_km', 'dist_km', 'gps_acc_med']].median()
prof['rides'] = g.size(); prof['pocket'] = g.ploc.apply(lambda s: (s == 0).mean())
prof['inc_per_100km'] = g.inc.sum() / g.dist_km.sum() * 100; prof['scary_per_100km'] = g.scary.sum() / g.dist_km.sum() * 100
prof['km'] = g.dist_km.sum()
def name_cluster(r):
    if r.stops_per_km == prof.stops_per_km.max(): return 'Stop-and-go'
    if r.moving_kmh == prof.moving_kmh.max(): return 'Steady cruisers'
    return 'Relaxed riders'
prof['name'] = prof.apply(name_cluster, axis=1); X['name'] = X.cl.map(prof.name)
prof.to_csv(os.path.join(OUT, 'q2_profiles.csv')); R['q2_profiles'] = prof.round(3).reset_index().to_dict('records')
# Poisson-style CI for incident rate per cluster (normal approx on counts)
R['q2_rate_ci'] = {prof.loc[c, 'name']: [float((g.inc.sum()[c] - 1.96 * np.sqrt(g.inc.sum()[c])) / prof.loc[c, 'km'] * 100),
                                          float((g.inc.sum()[c] + 1.96 * np.sqrt(g.inc.sum()[c])) / prof.loc[c, 'km'] * 100)] for c in prof.index}
XB, lb = labels[('June only', 'Baseline (midterm)')]; XP, lp = labels[('June only', 'Proposed')]
R['june_pocket'] = dict(baseline=XB.assign(c=lb).groupby('c').agg(n=('ride', 'size'), pocket=('ploc', lambda s: (s == 0).mean()), gps=('gps_acc_med', 'median')).round(3).to_dict('index'),
                        proposed=XP.assign(c=lp).groupby('c').agg(n=('ride', 'size'), pocket=('ploc', lambda s: (s == 0).mean()), gps=('gps_acc_med', 'median')).round(3).to_dict('index'))

# Fig 3: clustering metrics baseline vs proposed (June, where the artifact appeared, and all months)
mets = [('cramers_v_phone', "Link to\nphone\nposition ↓", ''), ('cramers_v_gpsq', "Link to\nGPS\nquality ↓", ''),
        ('silhouette', 'Silhouette\n↑', ''), ('stability_ari', 'Stability\n(ARI) ↑', '')]
fig, axs = plt.subplots(1, 2, figsize=(6.5, 3.4), dpi=200, sharey=True)
for ax, scope in zip(axs, ['June only', 'All 3 months']):
    q = Q2[Q2.scope == scope].set_index('method')
    xx = np.arange(len(mets))
    for j, (mname, col) in enumerate([('Baseline (midterm)', GRAY), ('Proposed', BLUE)]):
        vals = [q.loc[mname, m[0]] for m in mets]
        bb = ax.bar(xx + (j - 0.5) * 0.38, vals, 0.36, color=col, label=mname)
        for b in bb: ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.015, f'{b.get_height():.2f}', ha='center', fontsize=7.5, color=INK)
    ax.set_xticks(xx); ax.set_xticklabels([m[1] for m in mets], fontsize=8)
    ax.set_title(f'{scope} (n = {int(q.n.iloc[0]):,} rides)', fontsize=9.5, loc='left')
    ax.yaxis.grid(True, color=GRID); ax.set_axisbelow(True); ax.set_ylim(0, 1.05)
axs[0].set_ylabel('Metric value'); axs[1].legend(loc='upper left', fontsize=8)
fig.tight_layout(); fig.savefig(os.path.join(FIG, 'fig3_clustering.png')); plt.close()

# Fig 4: proposed riding styles scatter
cols = {'Steady cruisers': BLUE, 'Relaxed riders': AQUA, 'Stop-and-go': ORANGE}
fig, ax = plt.subplots(figsize=(6.5, 3.6), dpi=200)
for nm in ['Relaxed riders', 'Steady cruisers', 'Stop-and-go']:
    s = X[X.name == nm]
    ax.scatter(s.moving_kmh, s.stops_per_km.clip(upper=8), s=9, alpha=0.55, color=cols[nm], linewidths=0, label=f'{nm} ({len(s):,})')
ax.set_xlabel('Moving speed (km/h)'); ax.set_ylabel('Stops per km (capped at 8)'); ax.set_xlim(5, 30)
ax.grid(True, color=GRID); ax.set_axisbelow(True); ax.legend(loc='upper right', fontsize=8.5, markerscale=2)
fig.tight_layout(); fig.savefig(os.path.join(FIG, 'fig4_styles.png')); plt.close()

# ---------- Q3 hot spots ----------
folds = [(['2023_05'], ['2023_06']), (['2023_06'], ['2023_07']), (['2023_05', '2023_06'], ['2023_07'])]
allr = []
for tr_m, te_m in folds:
    tr = hs.cell_table(pts[pts.month.isin(tr_m)], inc[inc.month.isin(tr_m)], PARAMS['cell_m'])
    te = hs.cell_table(pts[pts.month.isin(te_m)], inc[inc.month.isin(te_m)], PARAMS['cell_m'])
    r, b, n = hs.evaluate(tr, te); r['fold'] = ' + '.join(m[-2:] for m in tr_m) + ' -> ' + te_m[0][-2:]; r['test_cells'] = n; r['prior_b'] = b
    allr.append(r)
Q3 = pd.concat(allr); Q3.to_csv(os.path.join(OUT, 'q3_hotspots_folds.csv'), index=False)
Q3m = Q3.groupby('method', sort=False)[['spearman', 'lift@25', 'capture@25', 'lift@50', 'capture@50']].mean()
Q3m.to_csv(os.path.join(OUT, 'q3_hotspots_mean.csv')); R['q3_mean'] = Q3m.round(3).reset_index().to_dict('records')
R['q3_folds'] = Q3.round(3).to_dict('records')

# Fig 5: lift@k curve, main fold (May + June -> July)
tr = hs.cell_table(pts[pts.month.isin(['2023_05', '2023_06'])], inc[inc.month.isin(['2023_05', '2023_06'])], PARAMS['cell_m'])
te = hs.cell_table(pts[pts.month == '2023_07'], inc[inc.month == '2023_07'], PARAMS['cell_m'])
scs, b = hs.scores(tr); tev = te[te.rides >= 5]; city = tev.inc.sum() / tev.rides.sum()
ks = np.arange(10, 151, 5)
mcol = {'Raw incident count': GRAY, 'Raw rate (incidents / rides)': ORANGE, 'Empirical Bayes rate': BLUE, 'Gi* hot spot (EB rate)': AQUA}
fig, axs = plt.subplots(1, 2, figsize=(6.5, 3.1), dpi=200)
for nm, s in scs.items():
    s = hs.rank(s.reindex(tev.index).fillna(-np.inf))
    lift = [(tev.loc[s.index[:k], 'inc'].sum() / tev.loc[s.index[:k], 'rides'].sum()) / city for k in ks]
    cap = [tev.loc[s.index[:k], 'inc'].sum() / tev.inc.sum() * 100 for k in ks]
    axs[0].plot(ks, lift, color=mcol[nm], lw=2, label=nm); axs[1].plot(ks, cap, color=mcol[nm], lw=2, label=nm)
axs[0].set_xlabel('Top-k cells flagged in May-June'); axs[0].set_ylabel('July incident rate in flagged\ncells / city rate (lift)')
axs[1].set_xlabel('Top-k cells flagged in May-June'); axs[1].set_ylabel('Share of July incidents\nin flagged cells (%)')
for ax in axs: ax.grid(True, color=GRID); ax.set_axisbelow(True)
axs[0].axhline(1, color=INK2, lw=1, ls='--')
h, l = axs[0].get_legend_handles_labels()
fig.legend(h, l, loc='lower center', ncol=2, fontsize=8)
fig.tight_layout(rect=(0, 0.13, 1, 1)); fig.savefig(os.path.join(FIG, 'fig5_lift.png')); plt.close()

# Fig 6: map, raw count top 50 vs EB top 50 cells, with July incidents
size = PARAMS['cell_m']
def cell_xy(idx): return (idx // 100000) * size, (idx % 100000) * size
fig, axs = plt.subplots(1, 2, figsize=(6.5, 3.5), dpi=200)
pp = hs.inbox(pts[pts.month.isin(['2023_05', '2023_06'])]).sample(150000, random_state=0)
cx0, cy0 = to_xy(52.5163, 13.3777)   # Brandenburg Gate as origin
px, py = to_xy(pp.lat.values, pp.lon.values); px, py = px - cx0, py - cy0
ij = hs.inbox(inc[inc.month == '2023_07']); ix_, iy_ = to_xy(ij.lat.values, ij.lon.values); ix_, iy_ = ix_ - cx0, iy_ - cy0
top = {}
for ax, nm in zip(axs, ['Raw incident count', 'Empirical Bayes rate']):
    s = hs.rank(scs[nm]).index[:50]; top[nm] = s
    ax.scatter(px / 1000, py / 1000, s=0.05, color='#c9c8c3', linewidths=0, rasterized=True)
    ax.scatter(ix_ / 1000, iy_ / 1000, s=2.5, color=ORANGE, linewidths=0, alpha=0.7, zorder=2)
    cx, cy = cell_xy(np.asarray(s)); cx, cy = cx - cx0, cy - cy0
    for a, b_ in zip(cx, cy): ax.add_patch(plt.Rectangle((a / 1000, b_ / 1000), size / 1000, size / 1000, facecolor='none', edgecolor=BLUE, lw=1.3, zorder=3))
    ax.set_title('Top 50 cells: ' + ('raw incident count' if nm.startswith('Raw') else 'Empirical Bayes rate'), fontsize=9, loc='left'); ax.set_aspect('equal')
    ax.set_xlabel('km east of Brandenburg Gate'); ax.tick_params(labelsize=7)
    ax.set_xlim(-6, 9); ax.set_ylim(-6, 6)
axs[0].set_ylabel('km north of Brandenburg Gate')
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
fig.legend([Patch(facecolor='none', edgecolor=BLUE, lw=1.3), Line2D([], [], marker='o', ls='', color=ORANGE, ms=4), Line2D([], [], marker='o', ls='', color='#c9c8c3', ms=4)],
           ['Flagged 250 m cell (May-June)', 'July near miss', 'Ride GPS points (May-June)'], loc='lower center', ncol=3, fontsize=8)
fig.tight_layout(rect=(0, 0.07, 1, 1)); fig.savefig(os.path.join(FIG, 'fig6_hotspot_map.png')); plt.close()
ov = len(set(top['Raw incident count']) & set(top['Empirical Bayes rate']))
trv = tr[tr.rides > 0]; ebv, _ = hs.eb_rate(trv)
R['q3_case'] = dict(overlap_top50=ov, prior_b=float(b), city_rate_test=float(city),
                    raw_top50_median_rides=float(trv.loc[top['Raw incident count'], 'rides'].median()),
                    eb_top50_median_rides=float(trv.loc[top['Empirical Bayes rate'], 'rides'].median()),
                    train_cells=int((tr.rides > 0).sum()), test_cells=int(len(tev)))
# top 5 EB cells details for case study
t5 = hs.rank(ebv).index[:5]
R['q3_top5'] = [dict(cell=int(c), lat=float(np.mean(hs.inbox(pts[pts.month.isin(['2023_05','2023_06'])]).assign(cell=lambda df: hs.cell_id(df.lat.values, df.lon.values, size)).query('cell == @c').lat)),
                     lon=float(np.mean(hs.inbox(pts[pts.month.isin(['2023_05','2023_06'])]).assign(cell=lambda df: hs.cell_id(df.lat.values, df.lon.values, size)).query('cell == @c').lon)),
                     rides=int(trv.loc[c, 'rides']), inc=int(trv.loc[c, 'inc']), eb_rate=float(ebv[c]),
                     july_rides=int(te.rides.get(c, 0)), july_inc=int(te.inc.get(c, 0))) for c in t5]

# ---------- Q4 runtime ----------
g_all = d['gps'] if 'gps' in d else None
times = []
for m in ['2023_05', '2023_06', '2023_07']:
    gm = pd.read_pickle(f'{P_DIR}/m_{m}.pkl')['gps']
    for c in ['lat', 'lon', 'timeStamp', 'acc']: gm[c] = pd.to_numeric(gm[c], errors='coerce')
    gm = gm.dropna(subset=['lat', 'lon', 'timeStamp', 'acc'])
    t0 = time.perf_counter(); n = 0
    for rid, g in gm.groupby('ride', sort=False):
        gc, _ = clean_ride(g)
        if gc is None: continue
        ride_features(smooth(gc, 5), 5); n += 1
    times.append(dict(month=m, rides=n, gps=len(gm), seconds=time.perf_counter() - t0))
T = pd.DataFrame(times); R['q4_runtime'] = T.round(3).to_dict('records')
R['q4_ms_per_ride'] = float(T.seconds.sum() / T.rides.sum() * 1000)
t0 = time.perf_counter(); hs.evaluate(tr, te); R['q4_hotspot_seconds'] = time.perf_counter() - t0
X0 = F[F.config == 'both5'].dropna(subset=cl.FEATS).reset_index(drop=True)
t0 = time.perf_counter(); cl.KMeans(3, n_init=20, random_state=0).fit(cl.design(X0, True).values); R['q4_kmeans_seconds'] = time.perf_counter() - t0
R['params'] = PARAMS

json.dump(R, open(os.path.join(OUT, 'results.json'), 'w'), indent=1, default=lambda o: o.item() if hasattr(o, 'item') else str(o))
print(json.dumps({k: R[k] for k in ['data', 'q1_june', 'q3_case', 'q4_ms_per_ride', 'fig2']}, indent=1, default=str))
print(Q3m.round(3)); print(prof.round(2)); print(R['q2_rate_ci'])
