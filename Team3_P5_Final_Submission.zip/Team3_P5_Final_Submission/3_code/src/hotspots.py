"""Hot spot scoring on a 250 m grid (Q3).

cell_table(): rides and near misses per cell. eb_rate(): Gamma-Poisson empirical Bayes rate per ride.
gi_star(): Getis-Ord Gi* z-score of the EB rate (3x3 neighborhood). evaluate(): lift@k / capture@k on a later month.
"""
import numpy as np, pandas as pd
from scipy.stats import spearmanr
from pipeline import cell_id
BBOX = (52.33, 52.68, 13.08, 13.77)
def inbox(df): return df[df.lat.between(*BBOX[:2]) & df.lon.between(*BBOX[2:])]
def cell_table(pts, inc, size):
    p = inbox(pts).copy(); p['cell'] = cell_id(p.lat.values, p.lon.values, size)
    i = inbox(inc).copy(); i['cell'] = cell_id(i.lat.values, i.lon.values, size)
    rides = p.drop_duplicates(['ride', 'cell']).groupby('cell').size().rename('rides')
    return pd.concat([rides, i.groupby('cell').size().rename('inc'), i.groupby('cell').scary.sum().rename('scary')], axis=1).fillna(0)
def eb_rate(t):
    """Gamma-Poisson empirical Bayes rate per ride, shrinks low-exposure cells toward the city rate."""
    t = t[t.rides > 0]; mu = t.inc.sum() / t.rides.sum()
    raw = t.inc / t.rides; w = t.rides / t.rides.sum()
    var = max(np.sum(w * (raw - mu) ** 2) - mu / t.rides.mean(), 1e-9)   # method of moments
    b = mu / var                     # prior strength in rides
    return (t.inc + mu * b) / (t.rides + b), b
def gi_star(t, size_dummy=None):
    """Getis-Ord Gi* z-score of the EB rate with a 3x3 (queen + self) neighborhood of cells."""
    r, _ = eb_rate(t); x = r.reindex(t.index).fillna(r.mean())
    ix, iy = t.index // 100000, t.index % 100000
    lookup = dict(zip(zip(ix, iy), x.values)); n = len(x); xb = x.mean(); s = np.sqrt((x ** 2).mean() - xb ** 2)
    z = []
    for a, b_ in zip(ix, iy):
        vals = [lookup[(a + dx, b_ + dy)] for dx in (-1, 0, 1) for dy in (-1, 0, 1) if (a + dx, b_ + dy) in lookup]
        w = len(vals); num = sum(vals) - xb * w
        den = s * np.sqrt((n * w - w ** 2) / (n - 1))
        z.append(num / den if den > 0 else 0)
    return pd.Series(z, index=t.index)
def scores(train):
    t = train[train.rides > 0]
    eb, b = eb_rate(t)
    return {'Raw incident count': t.inc,
            'Raw rate (incidents / rides)': (t.inc / t.rides).where(t.rides >= 5, 0),
            'Empirical Bayes rate': eb,
            'Gi* hot spot (EB rate)': gi_star(t)}, b
def rank(s):
    """Sort cells by score, highest first; ties broken by cell id so results are reproducible."""
    return s.sort_index().sort_values(ascending=False, kind='mergesort')
def evaluate(train, test, ks=(25, 50), min_test_rides=5):
    sc, b = scores(train)
    te = test[test.rides >= min_test_rides]; city = te.inc.sum() / te.rides.sum()
    rows = []
    for name, s in sc.items():
        s = s.reindex(te.index).fillna(-np.inf)
        both = te.index.intersection(train[train.rides >= min_test_rides].index)
        r = dict(method=name, spearman=spearmanr(s.reindex(both), te.loc[both, 'inc'] / te.loc[both, 'rides']).statistic)
        for k in ks:
            top = rank(s).index[:k]
            r[f'lift@{k}'] = (te.loc[top, 'inc'].sum() / te.loc[top, 'rides'].sum()) / city
            r[f'capture@{k}'] = te.loc[top, 'inc'].sum() / te.inc.sum()
        rows.append(r)
    return pd.DataFrame(rows), b, len(te)
