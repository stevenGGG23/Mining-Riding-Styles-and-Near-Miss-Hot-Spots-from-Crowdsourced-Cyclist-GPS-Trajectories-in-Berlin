"""Loads built.pkl (output of build.py), keeps the latest re-upload of each ride (#2 files),
and returns ride features, smoothed points and near misses for run_experiments.py.
"""
import sys, numpy as np, pandas as pd
from scipy.stats import spearmanr
def load(P_DIR):
    d = pd.read_pickle(f'{P_DIR}/built.pkl')
    F = d['F'].copy()
    F['base'] = F.ride.str.replace(r'(#|%23)\d+$', '', regex=True)
    F['ver'] = F.ride.str.extract(r'(?:#|%23)(\d+)$')[0].fillna(1).astype(int)
    keep = F.drop_duplicates('ride').sort_values('ver').drop_duplicates('base', keep='last').ride
    F = F[F.ride.isin(keep)]
    pts = d['pts'][d['pts'].ride.isin(keep)].copy(); pts['lat'] = pts.lat.round(6); pts['lon'] = pts.lon.round(6)
    inc = d['incs'][d['incs'].ride.isin(keep)].copy()
    for c in ['lat','lon','incident','scary']: inc[c] = pd.to_numeric(inc[c], errors='coerce')
    inc = inc.dropna(subset=['lat','lon'])
    return F, pts, inc, d
