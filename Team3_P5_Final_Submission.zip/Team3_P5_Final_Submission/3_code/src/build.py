"""Step 2 of the batch run: cleans every ride, computes features under the 8 smoothing settings (Q1),
smooths points for hot spots, and saves everything to built.pkl.
Usage: python build.py <src_dir> <pickle_dir>   (expects m_2023_05/06/07.pkl from extract.py)
"""
import sys, time, numpy as np, pandas as pd
sys.path.insert(0, sys.argv[1]); from pipeline import *
P_DIR = sys.argv[2]
months = ['2023_05', '2023_06', '2023_07']
CONFIGS = [('raw',1,1),('pos3',3,1),('pos5',5,1),('pos7',7,1),('speed5',1,5),('both3',3,3),('both5',5,5),('both7',7,7)]
feats, pts, incs, metas, log, timing = [], [], [], [], [], []
for m in months:
    d = pd.read_pickle(f'{P_DIR}/m_{m}.pkl')
    meta = d['meta']; metas.append(meta)
    g_all = d['gps'].copy()
    for c in ['lat','lon','timeStamp','acc']: g_all[c] = pd.to_numeric(g_all[c], errors='coerce')
    g_all = g_all.dropna(subset=['lat','lon','timeStamp','acc'])
    n0 = len(g_all)
    t0 = time.perf_counter(); kept = 0; spikes = 0; badacc = (g_all.acc > PARAMS['max_gps_error_m']).sum()
    for rid, g in g_all.groupby('ride', sort=False):
        gc, sp = clean_ride(g); spikes += sp
        if gc is None: continue
        for name, pw, sw in CONFIGS:
            f = ride_features(smooth(gc, pw), sw)
            if f is None: break
            f.update(ride=rid, month=m, config=name, pos_window=pw, speed_window=sw); feats.append(f)
        else:
            kept += 1
            gs = smooth(gc, PARAMS['smooth_window'])
            pts.append(pd.DataFrame(dict(ride=rid, month=m, lat=gs.lat.values, lon=gs.lon.values)))
    el = time.perf_counter() - t0
    timing.append(dict(month=m, rides_in=len(meta), rides_kept=kept, gps_in=n0, seconds=el))
    log.append(dict(month=m, files=len(meta) + d['bad'], gps_fixes=n0, dropped_acc=int(badacc), dropped_spike=spikes, rides_kept=kept))
    if len(d['incs']):
        i = d['incs'][['ride', 'lat', 'lon', 'incident', 'scary'] + [f'i{k}' for k in range(1, 11)]].copy(); i['month'] = m; incs.append(i)
    print(m, timing[-1], flush=True)
F = pd.DataFrame(feats)
full = F.groupby('ride').config.nunique(); F = F[F.ride.isin(full[full == len(CONFIGS)].index)]
meta = pd.concat(metas); F = F.merge(meta[['ride', 'bike', 'ploc']], on='ride', how='left')
pd.to_pickle(dict(F=F, pts=pd.concat(pts), incs=pd.concat(incs), log=pd.DataFrame(log), timing=pd.DataFrame(timing)), f'{P_DIR}/built.pkl')
print(pd.DataFrame(log)); print('rides with all windows', F.ride.nunique())
