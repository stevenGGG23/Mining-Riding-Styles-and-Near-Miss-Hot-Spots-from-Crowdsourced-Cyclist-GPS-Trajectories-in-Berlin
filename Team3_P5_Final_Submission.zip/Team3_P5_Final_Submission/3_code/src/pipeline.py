"""Cyclist trajectory pipeline: cleaning, smoothing, features, clustering, grid hot spots."""
import numpy as np
import pandas as pd

R = 6371000.0
PARAMS = dict(
    max_gps_error_m=20,      # drop fixes with accuracy radius above this
    max_speed_ms=15,         # drop jumps implying more than 54 km/h
    min_points=10, min_dist_m=300, min_dur_s=120,
    smooth_window=5,         # rolling median window on positions, in GPS fixes (about 15 s at 3 s sampling)
    speed_window=5,          # rolling median window on speed before computing acceleration
    stop_speed_ms=1.0, stop_min_s=5,
    turn_deg=45, turn_min_step_m=3,
    hard_brake_ms2=-2.0,
    cell_m=250,              # hot spot grid cell size
)


def hav(la1, lo1, la2, lo2):
    p1, p2 = np.radians(la1), np.radians(la2)
    a = np.sin((p2 - p1) / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(np.radians(lo2 - lo1) / 2) ** 2
    return 2 * R * np.arcsin(np.sqrt(a))


def bearing(la1, lo1, la2, lo2):
    p1, p2, dl = np.radians(la1), np.radians(la2), np.radians(lo2 - lo1)
    x = np.sin(dl) * np.cos(p2)
    y = np.cos(p1) * np.sin(p2) - np.sin(p1) * np.cos(p2) * np.cos(dl)
    return (np.degrees(np.arctan2(x, y)) + 360) % 360


def clean_ride(g, P=PARAMS):
    """Accuracy filter, sort, remove speed spikes. Returns cleaned frame or None."""
    g = g.dropna(subset=['lat', 'lon', 'timeStamp', 'acc'])
    g = g[g.acc <= P['max_gps_error_m']].sort_values('timeStamp')
    g = g.drop_duplicates('timeStamp')
    if len(g) < P['min_points']:
        return None, 0
    la, lo, t = g.lat.values, g.lon.values, g.timeStamp.values / 1000.0
    d = hav(la[:-1], lo[:-1], la[1:], lo[1:])
    v = d / np.diff(t)
    spike = v > P['max_speed_ms']
    g = g[np.concatenate([[True], ~spike])]
    return (g if len(g) >= P['min_points'] else None), int(spike.sum())


def smooth(g, window):
    """Centered rolling median of lat/lon; window <= 1 returns the trace unchanged."""
    if window <= 1:
        return g
    g = g.copy()
    g['lat'] = g.lat.rolling(window, center=True, min_periods=1).median()
    g['lon'] = g.lon.rolling(window, center=True, min_periods=1).median()
    return g


def ride_features(g, speed_window=1, P=PARAMS):
    la, lo, t = g.lat.values, g.lon.values, g.timeStamp.values / 1000.0
    d = hav(la[:-1], lo[:-1], la[1:], lo[1:])
    dt = np.diff(t).astype(float)
    v = d / dt
    dist, dur = d.sum(), t[-1] - t[0]
    if dist < P['min_dist_m'] or dur < P['min_dur_s']:
        return None
    vs = pd.Series(v).rolling(speed_window, center=True, min_periods=1).median().values if speed_window > 1 else v
    acc = np.diff(vs) / dt[1:]
    b = bearing(la[:-1], lo[:-1], la[1:], lo[1:])
    db = np.abs((np.diff(b) + 180) % 360 - 180)
    moving = d > P['turn_min_step_m']
    turns = int(np.sum((db > P['turn_deg']) & moving[1:] & moving[:-1]))
    stopped = v < P['stop_speed_ms']
    stops, run = 0, 0.0
    for s, step in zip(stopped, dt):
        if s:
            run += step
        else:
            stops += run >= P['stop_min_s']; run = 0.0
    stops += run >= P['stop_min_s']
    km = dist / 1000
    mv = v[~stopped]
    return dict(dist_km=km, dur_min=dur / 60, moving_kmh=(mv.mean() * 3.6) if len(mv) else np.nan,
                p95_kmh=np.percentile(v, 95) * 3.6, stops_per_km=stops / km,
                stop_share=dt[stopped].sum() / dur, turns_per_km=turns / km,
                acc_std=np.std(acc), hard_brakes_per_km=np.sum(acc < P['hard_brake_ms2']) / km,
                gps_acc_med=float(np.median(g.acc)), n_gps=len(g))


def to_xy(lat, lon, lat0=52.52):
    """Local equirectangular projection in meters (accurate to well under 1% across Berlin)."""
    return (np.asarray(lon) * np.cos(np.radians(lat0)) * 111320.0, np.asarray(lat) * 110574.0)


def cell_id(lat, lon, size):
    x, y = to_xy(lat, lon)
    return (np.floor(x / size).astype(np.int64) * 100000 + np.floor(y / size).astype(np.int64))
