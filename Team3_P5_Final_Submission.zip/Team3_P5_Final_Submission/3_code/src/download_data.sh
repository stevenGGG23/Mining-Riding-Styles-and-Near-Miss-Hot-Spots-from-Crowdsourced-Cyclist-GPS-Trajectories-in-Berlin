#!/bin/bash
# Downloads the raw SimRa ride files for May, June and July 2023 (about 2,350 files).
# Usage: bash download_data.sh <url_list_dir> <raw_dir>
#   e.g. bash download_data.sh ../../2_data/raw_file_lists ./simra_raw
LISTS=${1:-../../2_data/raw_file_lists}; RAW=${2:-./simra_raw}
for m in 2023_05 2023_06 2023_07; do
  mkdir -p "$RAW/$m"
  while read -r url; do
    [ -z "$url" ] && continue
    f="$RAW/$m/$(basename "$url")"
    [ -f "$f" ] || curl -sSfL "$url" -o "$f"
  done < "$LISTS/urls_$m.txt"
  echo "$m: $(ls "$RAW/$m" | wc -l) files"
done
