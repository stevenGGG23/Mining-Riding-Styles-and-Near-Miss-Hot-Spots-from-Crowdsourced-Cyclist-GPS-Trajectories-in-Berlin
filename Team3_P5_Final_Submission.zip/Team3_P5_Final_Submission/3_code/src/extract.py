"""Step 1 of the batch run: extract GPS rows + incident rows from raw SimRa ride files of one month into a compact pickle.
Usage: python extract.py 2023_05 <raw_month_dir> m_2023_05.pkl
"""
import sys, os, io, re, glob, pandas as pd
month, rawdir, out = sys.argv[1], sys.argv[2], sys.argv[3]
gps, incs, meta = [], [], []
bad = 0
for f in sorted(glob.glob(os.path.join(rawdir, 'VM2_*'))):
    rid = os.path.basename(f)
    txt = open(f, errors='ignore').read()
    parts = re.split(r'\n={10,}\s*\n', txt, maxsplit=1)
    if len(parts) < 2:
        bad += 1; continue
    try:
        inc = pd.read_csv(io.StringIO(parts[0].split('\n', 1)[1]))
    except Exception:
        inc = pd.DataFrame()
    try:
        body = parts[1].strip().split('\n', 1)[1]
        df = pd.read_csv(io.StringIO(body), usecols=['lat', 'lon', 'timeStamp', 'acc'], low_memory=False)
    except Exception:
        bad += 1; continue
    g = df.dropna(subset=['lat', 'lon']).copy(); g['ride'] = rid
    gps.append(g)
    bike = int(inc['bike'].iloc[0]) if len(inc) and 'bike' in inc else -1
    ploc = int(inc['pLoc'].iloc[0]) if len(inc) and 'pLoc' in inc else -1
    meta.append(dict(ride=rid, month=month, bike=bike, ploc=ploc))
    if len(inc) and 'incident' in inc:
        r = inc[(inc['incident'] > 0) & inc['lat'].notna()].copy()
        if len(r):
            r['ride'] = rid; incs.append(r)
pd.to_pickle(dict(gps=pd.concat(gps), meta=pd.DataFrame(meta),
                  incs=pd.concat(incs) if incs else pd.DataFrame(), bad=bad), out)
print(month, 'rides', len(meta), 'unreadable', bad, 'gps rows', sum(len(x) for x in gps))
