"""Riding-style clustering (Q2).

design(): log-transform + standardize the 6 ride features; with phone_control=True, center each feature
within its phone-position group (Algorithm 2 in the report).
evaluate(): k-means plus Cramer's V (phone, GPS quality), silhouette, Davies-Bouldin and bootstrap ARI.
"""
import numpy as np, pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, davies_bouldin_score, adjusted_rand_score
from scipy.stats import chi2_contingency
FEATS = ['moving_kmh', 'p95_kmh', 'stops_per_km', 'stop_share', 'turns_per_km', 'acc_std']
def design(X, phone_control):
    Z = X[FEATS].copy()
    for c in ['stops_per_km', 'turns_per_km']: Z[c] = np.log1p(Z[c])
    Z['acc_std'] = np.log(Z['acc_std'])
    Z = pd.DataFrame(StandardScaler().fit_transform(Z), columns=FEATS, index=X.index)
    if phone_control:   # remove the part of each feature explained by phone position
        Z = Z - Z.groupby(X['ploc'].values).transform('mean')
        Z = pd.DataFrame(StandardScaler().fit_transform(Z), columns=FEATS, index=X.index)
    return Z
def cramers_v(a, b):
    t = pd.crosstab(a, b); chi2 = chi2_contingency(t)[0]; n = t.values.sum()
    return np.sqrt(chi2 / (n * (min(t.shape) - 1)))
def stability(Z, k, n_boot=20, seed=0):
    rng = np.random.default_rng(seed); base = KMeans(k, n_init=10, random_state=0).fit(Z)
    s = []
    for b in range(n_boot):
        idx = rng.choice(len(Z), len(Z), replace=True)
        km = KMeans(k, n_init=10, random_state=b).fit(Z[idx])
        s.append(adjusted_rand_score(base.predict(Z), km.predict(Z)))
    return float(np.mean(s))
def evaluate(X, phone_control, k):
    Z = design(X, phone_control).values
    lab = KMeans(k, n_init=20, random_state=0).fit_predict(Z)
    return lab, dict(silhouette=silhouette_score(Z, lab), davies_bouldin=davies_bouldin_score(Z, lab),
                     cramers_v_phone=cramers_v(lab, X['ploc'].values),
                     cramers_v_gpsq=cramers_v(lab, pd.qcut(X['gps_acc_med'], 4, labels=False, duplicates='drop').values),
                     stability_ari=stability(Z, k))
